
package assignmentq1;

import java.util.ArrayList;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;

public class StudentTest {

    private ArrayList<Student> students;

    @Before
    public void setUp() {
        students = new ArrayList<>();
    }

    @Test
    public void testSaveStudent() {
        // Create a student
        Student student = new Student("01", "Megan", 21, "megan@gmail.com", "IT");

        // Add the student to the list
        students.add(student);

        // Verify that the student is added to the list
        assertTrue(students.contains(student));
    }

    
    @Test
    public void testSearchStudentFound() {
        // Create a list to hold students
        ArrayList<Student> students = new ArrayList<>();

        // Create a student
        Student student = new Student("01", "Megan", 21, "megan@gmail.com", "IT");

        // Add the student to the list
        students.add(student);

        // Search for the student
        Student foundStudent = null; // Initialize foundStudent to null
        for (Student s : students) {
            if (s.getStudentId().equals("01")) {
                foundStudent = s;
                break; // Exit the loop once the student is found
            }
        }

        // Verify that the search returns the expected student
        assertNotNull(foundStudent); // Ensure that a student was found
        assertEquals(student.getStudentId(), foundStudent.getStudentId());
        assertEquals(student.getStudentName(), foundStudent.getStudentName());
        assertEquals(student.getStudentAge(), foundStudent.getStudentAge());
        assertEquals(student.getStudentEmail(), foundStudent.getStudentEmail());
        assertEquals(student.getStudentCourse(), foundStudent.getStudentCourse());
    }

    @Test
    public void testSearchStudentNotFound() {
         //Create a student
         Student student = new Student("01", "Megan", 21, "megan@gmail.com", "IT");

      //   Add the student to the list
        students.add(student);

     Student foundStudent = null; // Initialize foundStudent to null
     //    Verify that the search returns null (student not found)
           assertNull(foundStudent);
    }

    @Test
    public void testDeleteStudent() {
        // Create a student
        Student student = new Student("01", "Megan", 21, "megan@gmail.com", "IT");

        // Add the student to the list
        students.add(student);

        // Delete the student
        Student.DeleteStudent(students, "01");

        // Verify that the student is removed from the list
        assertFalse(students.contains(student));
    }

    @Test
    public void testDeleteStudent_StudentNotFound() {
        // Create a list to hold students
        ArrayList<Student> students = new ArrayList<>();

        // Create a student
        Student student = new Student("01", "Megan", 21, "megan@gmail.com", "IT");

        // Add the student to the list
        students.add(student);

        // Attempt to delete a student with an ID that doesn't exist in the list
        Student.DeleteStudent(students, "02");

        // Search for the student
        Student foundStudent = null; // Initialize foundStudent to null
        for (Student s : students) {
            if (s.getStudentId().equals("02")) {
                foundStudent = s;
                break; // Exit the loop once the student is found
            }
        }

        // Verify that the student is not removed from the list
        assertTrue(students.contains(student));
        assertNull(foundStudent); // Ensure that foundStudent is still null
    }
    
    @Test
    public void TestStudentAge_StudentAgeValid() {
        // Create a Student instance with a specific age
        Student student = new Student("01", "Megan", 21, "megan@gmail.com", "IT");

        // Call the getStudentAge() method
        int age = student.getStudentAge();

        // Assert that the returned age matches the expected age
        assertEquals(21, age);
    }


    @Test
    public void testStudentReport() {
        // Create multiple students
        Student student1 = new Student("01", "Megan", 21, "megan@gmail.com", "IT");
        Student student2 = new Student("02", "Bob", 32, "bob@outlook.com", "Law");

        // Add the students to the list
        students.add(student1);
        students.add(student2);

        // Generate a student report
        Student.StudentReport(students);
        
    }
}
