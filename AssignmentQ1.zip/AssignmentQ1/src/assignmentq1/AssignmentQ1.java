package assignmentq1;

import java.util.ArrayList; // Import the ArrayList class 
import java.util.Scanner; // Import the Scanner class 

public class AssignmentQ1 {

    public static void main(String[] args) {

        // Create an ArrayList to store Student objects
        ArrayList<Student> students = new ArrayList<>(); 
        Scanner kb = new Scanner(System.in); // Create a Scanner object to read user input

        // Declare a variable to store the user's main menu choice
        char mainMenu; 

        do {
            System.out.println("STUDENT MANAGEMENT APPLICATION" 
                    + "\n------------------------------------------------"); // Display a header
            System.out.println("Enter '1' to launch the menu or any other key to exit."); // Prompt the user to enter a choice
            System.out.print("Enter your choice: ");
            
           // Read the first character of input (user's choice)
            mainMenu = kb.nextLine().charAt(0); 

            if (mainMenu == '1') {
                showMenu(students, kb); // Call the showMenu function if the user chooses option 1
            } else {
                System.out.println("Exiting the program."); // Display an exit message
                System.exit(0); // Terminate the program
            }
             // Continue looping until the user exits
        } while (true);
    }

    public static void showMenu(ArrayList<Student> students, Scanner kb) {
        // Declare a variable to store the user's menu choice
        int choice; 
        do {
            
            // Display a menu
            System.out.println("\nPlease select ONE of the following: " 
                    + "\n------------------------------------------------"); 
            System.out.println("[1] Capture a New Student");
            System.out.println("[2] Search for a Student");
            System.out.println("[3] Delete a Student");
            System.out.println("[4] Print Student Report");
            System.out.println("[5] EXIT Application\n");

            System.out.print("Enter your choice: ");
            choice = Integer.parseInt(kb.nextLine()); // user's menu choice as an integer

            switch (choice) {
                case 1:
                    Student newStudent = Student.SaveStudent(); // Create a new Student object using a static method
                    students.add(newStudent); // Add the new student to the ArrayList
                    System.out.println("\n------------------------------------------------\n"
                                    + "Student details saved successfully."
                                    + "\n------------------------------------------------\n"); // Display a success message
                    break;

                case 2:
                    System.out.println("\nSEARCH FOR STUDENT " +
                                                        "\n---------------------");
                    System.out.print("Enter Student ID to search: ");
                    String searchId = kb.nextLine(); // Read the student ID to search for
                    Student.SearchStudent(students, searchId); // Call a static method to search for a student
                    break;

                case 3:
                    System.out.println("\nDELETE STUDENT PROFILE" +
                                                        "\n-----------------------");
                    System.out.print("Enter Student ID to delete: ");
                    String deleteId = kb.nextLine(); // Read the student ID to delete
                    
                     // Call a static method to delete a student
                    Student.DeleteStudent(students, deleteId);
                    break;

                     // Call a static method to print a student report
                case 4:
                    Student.StudentReport(students);
                    break;

                case 5:
                    ExitStudentApplication(); // Call a method to exit the application
                    break;

                    // Display an error message for an invalid choice
                default:
                    System.out.println("Invalid choice. Please select a valid option."); 
            }
        } while (choice != 5); // Continue looping until the user chooses to exit
    }

    public static void ExitStudentApplication() {
        System.out.println("Exiting the application."); // Display an exit message
        System.exit(0); // Terminate the program
    }
}
