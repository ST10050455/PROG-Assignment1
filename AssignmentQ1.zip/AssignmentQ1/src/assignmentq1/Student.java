package assignmentq1;

// Import necessary Java classes
import java.util.ArrayList;
import java.util.Scanner;

// Define a class named "Student"
public class Student {

    // Declare private instance variables to store student information
    private final String studentId;
    private final String studentName;
    private final int studentAge;
    private final String studentEmail;
    private final String studentCourse;

    // Constructor to initialize a new student object
    public Student(String id, String name, int age, String email, String course) {
         this.studentId = id;
         this.studentName = name;
         this.studentAge = age;
         this.studentEmail = email;
         this.studentCourse = course;
    }

    // Getter methods for accessing private fields
    public String getStudentId() {
        return studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public int getStudentAge() {
        return studentAge;
    }

    public String getStudentEmail() {
        return studentEmail;
    }

    public String getStudentCourse() {
        return studentCourse;
    }

    // Static method to capture information and create a new student object
    public static Student SaveStudent() {
        
        Scanner input = new Scanner(System.in);
        System.out.println("\nCAPTURE NEW STUDENT"
                + "\n---------------------");
        
        System.out.print("Enter Student ID: ");
        String id = input.nextLine();

        System.out.print("Enter Student Name: ");
        String name = input.nextLine();

        // Validate student age
        boolean validAge = false;
        int age = 0;
        
        while (!validAge) {
            System.out.print("Enter Student Age: ");
            if (input.hasNextInt()) {
                age = input.nextInt();
                if (age >= 16) {
                    validAge = true;
                } else {
                    System.out.println("Age must be 16 or older. Please re-enter! ");
                }           
            } else {
                System.out.println("Invalid input. Please re-enter the correct age! ");
                input.next(); // Clear the invalid input 
            }
        }

        input.nextLine(); //  the newline character

        System.out.print("Enter Student Email: ");
        String email = input.nextLine();

        System.out.print("Enter Student Course: ");
        String course = input.nextLine();

        return new Student(id, name, age, email, course);
    }
    
    // Static method to search for a student by ID
    public static void SearchStudent(ArrayList<Student> students, String searchId) {
        
        boolean studentFound = false;
           
        for (Student student : students) {
            if (student.getStudentId().equals(searchId)) {
                System.out.println("\nSTUDENT FOUND"
                    + "\n------------------------------------------------");
            
                System.out.println("Student ID: " + student.getStudentId());
                System.out.println("Student Name: " + student.getStudentName());
                System.out.println("Student Age: " + student.getStudentAge());
                System.out.println("Student Email: " + student.getStudentEmail());
                System.out.println("Student Course: " + student.getStudentCourse() 
                    
                    +"\n------------------------------------------------\n");           
                studentFound = true;
                break; // No need to continue searching
            }
        }
        if (!studentFound) {
            System.out.println("\n------------------------------------------------\n"
                + "Student with Student ID: " + searchId + " not found!"
                +"\n------------------------------------------------\n");
        }
    }

    // Static method to delete a student by ID
    public static void DeleteStudent(ArrayList<Student> students, String deleteId) {
        
        for (int i = 0; i < students.size(); i++) {
            if (students.get(i).getStudentId().equals(deleteId)) {
                students.remove(i);
                
                System.out.println("\n------------------------------------------------\n" +
                          "Student with Student ID: " + deleteId +" deleted successfully." +
                          "\n------------------------------------------------\n");
                return;
            }
        }
        System.out.println("\n------------------------------------------------\n" +
                  "Student with Student ID: " + deleteId +" not found!" +
                  "\n------------------------------------------------\n");
    }

    // Static method to print a report of all students
    public static void StudentReport(ArrayList<Student> students) {
        
        System.out.println("\nSTUDENT REPORT"
                + "\n------------------------------------------------\n");
        
        for (Student student : students) {
            System.out.println("Student ID: " + student.getStudentId());
            System.out.println("Student Name: " + student.getStudentName());
            System.out.println("Student Age: " + student.getStudentAge());
            System.out.println("Student Email: " + student.getStudentEmail());
            System.out.println("Student Course: " + student.getStudentCourse() 
                + "\n------------------------------------------------\n");
        }
    }

    // Instance method to exit the student application
    public void ExitStudentApplication() {
        System.out.println("Exiting the application.");
        System.exit(0);
    }
}
