package assignmentq2;

import java.util.Scanner;

class Song {
    private final String title; // Song title
    private final String artist; // Artist name

    public Song(String title, String artist) {
        this.title = title; // Initialize song title
        this.artist = artist; // Initialize artist name
    }

    public String getTitle() {
        return title; // Get song title
    }

    public String getArtist() {
        return artist; // Get artist name
    }
}


class Playlist {
    
    private final String name;  // Playlist name
    private final Song[ ] songs;    // Array to store songs in the playlist

    public Song[] getSongs() {
        return songs;
    }
    private int songCount;       // Number of songs in the playlist

    public Playlist(String name, int maxSize) {
        this.name = name;    // Initialize playlist name
        this.songs = new Song[maxSize];      // Create an array to store songs
        this.songCount = 0;  // Initialize song count to zero
    }
    
      public int getSongCount() {
        return songCount; // Get the number of songs in the playlist
    }

    public String getName() {
        return name;    // Get playlist name
    }
    
    public void addSong(Song song) {
        if (songCount < songs.length) {
            songs[songCount++] = song;   // Add a song to the playlist and increment the song count
            System.out.println("\nSong added to the playlist: " + song.getTitle() +" - "+ song.getArtist()+"\n");
        } else {
            System.out.println("Playlist is full. Cannot add more songs.");
        }
    }
    
    //displays songs with the playlist name
    public void displaySongs() {
        System.out.println("\nSongs in Playlist '" + name.toUpperCase() + "'"//changes any input to UPPERCASE
                + "\n---------------------------");
        for (int i = 0; i < songCount; i++) {
            System.out.println((i + 1) + ". " + songs[i].getTitle() + " -- " + songs[i].getArtist());
        }
    }
}

public class AssignmentQ2 {
    public static void main(String[ ] args) {

        System.out.println("Customize Your Playlist!");

        //scanner input for user
        Scanner scanner = new Scanner(System.in);
        
        //arrays
        Playlist[ ] playlists = new Playlist[5];
        int playlistCount = 0;

        while (true) {
            System.out.println("\n*** PLAYLIST  MENU ***"
                    + "\n---------------------------");
            System.out.println("[1] Create a new playlist");
            System.out.println("[2] Add a song to a playlist");
            System.out.println("[3] Search playlist by name");
            System.out.println("[4] Exit");
            
            System.out.print("\nEnter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            //switch case for music menu
            switch (choice) {
                case 1:
                    createPlaylist(playlists, playlistCount);
                    playlistCount++;
                    break;
                    
                case 2:
                    addSongToPlaylist(playlists, playlistCount);
                    break;
                    
                case 3:
                    searchForPlaylist(playlists, playlistCount);
                    break;
                    
                case 4:
                    System.out.println("\nThank you for using the Playlist Manager!");
                    scanner.close();
                    System.exit(0);
                    
               //when the user inputs a number not found on the menu     
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    
    public static void createPlaylist(Playlist[] playlists, int playlistCount) {
        Scanner kb = new Scanner(System.in);
        //if statement for playlist limit
        if (playlistCount < playlists.length) {
            System.out.print( "Playlist Name: ");
            String playlistName = kb.nextLine(); 
            
            playlists[playlistCount] = new Playlist(playlistName, 10); //limigt of 10 playlists
            
            //Uppercase to display the playlist name clearly
            System.out.println("\n---------------------------\n"
                    + "Playlist '" + playlistName.toUpperCase() + "' created."
                                            + "\n---------------------------\n");
        } else {
            System.out.println("Cannot create more playlists. Limit Reached"); // 'error' message
        }
    }

    //method to add songs
    public static void addSongToPlaylist(Playlist[] playlists, int playlistCount) {
        
        Scanner kb = new Scanner(System.in);
        System.out.print("Playlist Name (existing):");
        String playlistName = kb.nextLine();
        
        Playlist selectedPlaylist = null;
        
        //for loop 
        for (int i = 0; i < playlistCount; i++) {
            if (playlists[i].getName().equals(playlistName)) {
                selectedPlaylist = playlists[i];
                break;
            }
        }
        if (selectedPlaylist != null) {
            System.out.print("\nEnter Song Title: ");
            String songTitle = kb.nextLine();
            
            System.out.print("Enter Artist Name: ");
            String artistName = kb.nextLine() + "\n"; 
            
            selectedPlaylist.addSong(new Song(songTitle, artistName));
        } else {
            System.out.println("Playlist not found!");
        }
    }

    //search method for playlist name
    public static void searchForPlaylist(Playlist[] playlists, int playlistCount) {
          Scanner kb = new Scanner(System.in);
        //ask user input
        System.out.print("Search Playlist Name: ");
        String searchName = kb.nextLine();
        
        boolean found = false;
        for (int i = 0; i < playlistCount; i++) {
            
            //checks if the search name and saved playlist name matches
            if (playlists[i].getName().equals(searchName)) {
                playlists[i].displaySongs();
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("\n---------------------------\n"
                    + "Playlist Not Found!"
                    + "\n---------------------------\n");
        }
    }
}
