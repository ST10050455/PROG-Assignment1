/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package assignmentq2;

import static org.junit.Assert.*;
import org.junit.Test;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

public class AssignmentQ2Test {
    
AssignmentQ2 Playlist = new AssignmentQ2();

    @Test
    public void testCreatePlaylist() {
        Playlist[] playlists = new Playlist[5]; // Assuming a limit of 5 playlists
        int playlistCount = 0;

        // Simulate user input for creating a playlist
        String input = "Campus Playlist\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        Playlist.createPlaylist(playlists, playlistCount);

        assertEquals("Campus Playlist", playlists[0].getName());
    }

    @Test
    public void testAddSongToPlaylist() {
        Playlist[] playlists = new Playlist[5];
        int playlistCount = 1; // Assuming one playlist already exists

        // Create a sample playlist
        playlists[0] = new Playlist("Campus Playlist", 10);

        // Simulate user input for adding a song to the playlist
        String input = "Campus Playlist\n Song\n Artist\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        Playlist.addSongToPlaylist(playlists, playlistCount);

        assertEquals(1, playlists[0].getSongCount());

    }

    @Test
    public void testSearchForPlaylist() {
        Playlist[] playlists = new Playlist[5];
        int playlistCount = 2; // Assuming two playlists exist

        // Create sample playlists
        playlists[0] = new Playlist("Campus Playlist 1", 10);
        playlists[1] = new Playlist("Campus Playlist 2", 10);

        // Redirect standard input to simulate user input
        String input = "Campus Playlist 1\n";
        InputStream in = new ByteArrayInputStream(input.getBytes());
        System.setIn(in);

        // Capture standard output to check if the playlist is found
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outContent));

        Playlist.searchForPlaylist(playlists, playlistCount);

        assertFalse(outContent.toString().contains("Campus Playlist 1"));
        assertFalse(outContent.toString().contains("Campus Playlist 2"));
    }
}

